
CryptoGrow — Simple static starter site (Demo)
=============================================

What's included:
- index.html : Static frontend with wallet connect (MetaMask) demo using ethers.js CDN.
- styles.css : Minimal styling.
- script.js  : Client-side logic: connect wallet, show referral link, simulate activation.

How to deploy (quick, free):
1. Create a new GitHub repository (public).
2. Upload these files to the repo.
3. On Vercel, choose "Import Git Repository" and select the repo.
4. Use framework: "Other" or "Static Site" and deploy.
5. Your site will be available like https://<project>.vercel.app

Important:
- This is a demo / starter. It does NOT send or receive real tokens.
- For production you must integrate a backend (Firebase) and a smart contract (BEP20) and secure all flows.
