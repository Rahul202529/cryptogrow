
// Minimal client-side wallet connect + simulated logic
const connectBtn = document.getElementById('connectBtn');
const addrEl = document.getElementById('addr');
const refLinkInput = document.getElementById('refLink');
const copyRefBtn = document.getElementById('copyRef');
const activationMsg = document.getElementById('activationMsg');
const refListEl = document.getElementById('refList');
const msgEl = document.getElementById('msg');

let userAddress = null;
let refList = [];

async function connectWallet() {
  if (window.ethereum === undefined) {
    alert('MetaMask nahi mila. Mobile par Trust Wallet + WalletConnect use karein.');
    return;
  }
  try {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    await provider.send('eth_requestAccounts', []);
    const signer = provider.getSigner();
    userAddress = await signer.getAddress();
    addrEl.textContent = userAddress;
    connectBtn.textContent = 'Connected';
    connectBtn.disabled = true;
    // set referral link
    const code = 'CG-' + userAddress.slice(2,8).toUpperCase();
    refLinkInput.value = window.location.origin + '/?ref=' + code;
    updateRefListUI();
  } catch (e) {
    console.error(e);
    alert('Connection failed: ' + (e.message || e));
  }
}

connectBtn.addEventListener('click', connectWallet);

document.querySelectorAll('.activate').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    const amt = btn.dataset.amount;
    if (!userAddress) { activationMsg.textContent = 'Pehle wallet connect karo.'; return; }
    activationMsg.textContent = `Activated with $${amt}. Daily rewards: ${amt==50? '1%':'0.5%/0.75%'} (simulated). Token transfer simulated.`;
    // simulate referral credit if any ref param
    const urlParams = new URLSearchParams(window.location.search);
    const ref = urlParams.get('ref');
    if (ref) {
      // credit the ref (simulate)
      refList.push({wallet: ref, amount: '$'+amt, joined: new Date().toLocaleDateString()});
      updateRefListUI();
    }
  });
});

copyRefBtn.addEventListener('click', async ()=>{
  try {
    await navigator.clipboard.writeText(refLinkInput.value);
    msgEl.textContent = 'Referral link copied to clipboard';
  } catch (e) {
    msgEl.textContent = 'Copy failed';
  }
});

document.getElementById('buy25').addEventListener('click', ()=>{
  if (!userAddress) { msgEl.textContent = 'Pehle wallet connect karo.'; return; }
  msgEl.textContent = 'Purchase $25 recorded — bonus 1% tokens (simulated).';
});
document.getElementById('buy100').addEventListener('click', ()=>{
  if (!userAddress) { msgEl.textContent = 'Pehle wallet connect karo.'; return; }
  msgEl.textContent = 'Purchase $100 recorded — bonus 1% tokens (simulated).';
});

function updateRefListUI(){
  if (refList.length === 0) {
    refListEl.innerHTML = '<em>No referrals yet</em>';
    return;
  }
  refListEl.innerHTML = '';
  refList.forEach(r=>{
    const div = document.createElement('div');
    div.textContent = r.wallet + ' — ' + r.amount + ' — ' + r.joined;
    refListEl.appendChild(div);
  });
}

// auto-populate ref if user clicked a referral link
(function(){
  const urlParams = new URLSearchParams(window.location.search);
  const ref = urlParams.get('ref');
  if (ref) {
    refList.push({wallet: ref, amount: '-', joined: new Date().toLocaleDateString()});
    updateRefListUI();
  }
})();
